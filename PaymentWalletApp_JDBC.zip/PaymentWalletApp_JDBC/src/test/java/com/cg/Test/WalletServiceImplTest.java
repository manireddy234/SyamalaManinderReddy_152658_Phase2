package com.cg.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.sql.SQLException;

import org.junit.Test;

import com.cg.PaymentWalletApp.Exception.BankException;
import com.cg.PaymentWalletApp.bean.Customer;
import com.cg.PaymentWalletApp.bean.Wallet;
import com.cg.PaymentWalletApp.service.IWalletService;
import com.cg.PaymentWalletApp.service.WalletServiceImpl;

public class WalletServiceImplTest {
	public static IWalletService iWalletService=new WalletServiceImpl();
	
    @Test
	public void addCustomerTestTrue() throws BankException
	{
		Customer customer1 = new Customer("9573765650","Mani","Mani@0306","mani123@gmail.com",new Wallet());
		assertEquals("9573765650",iWalletService.addCustomer(customer1));
			
	}
    @Test
  	public void addCustomerTestFalse() throws BankException
  	{

  		Customer customer2 = new Customer("9100501001","Neeraj","Neeraj@123","Neeraj123@gmail.com",new Wallet());
  		assertNotEquals("56968621",iWalletService.addCustomer(customer2));
  		
  	}
	

	@Test
	public void initBalanceTest() throws BankException
	{
		Customer customer3 = new Customer("9052263421","Pavan","Pavan@123","Pavan123@gmail.com",new Wallet());
		iWalletService.addCustomer(customer3);
		assertEquals(BigDecimal.valueOf(0.0),customer3.getWallet().getBalance());
		
	}
	
	@Test
	public void depositMoneyTest() throws BankException, ClassNotFoundException, SQLException
	{
		Customer customer4 = new Customer("9505047643","Mani","Mani@0306","Mani123@gmail.com",new Wallet());
		iWalletService.addCustomer(customer4);
		iWalletService.deposit(customer4, BigDecimal.valueOf(8500.00));
		Customer result = iWalletService.showBalance("9505047643", "Mani@0306");
		assertEquals(BigDecimal.valueOf(8500.00),result.getWallet().getBalance());
	}
	@Test
	public void withdrawMoneyTestTrue() throws BankException, ClassNotFoundException, SQLException
	{
		Customer customer5 = new Customer("9505047642","Mani","Mani@0306","Mani123@gmail.com",new Wallet());
		iWalletService.addCustomer(customer5);
		iWalletService.deposit(customer5, BigDecimal.valueOf(8500.00));
		assertTrue(iWalletService.withDraw(customer5, BigDecimal.valueOf(3000.00)));
	}

	
	@Test(expected = BankException.class)
	public void withdrawMoneyTestFalse() throws BankException, ClassNotFoundException, SQLException
	{
		Customer customer6 = new Customer("9505047641","Mani","Mani@0306","Mani123@gmail.com",new Wallet());
		iWalletService.addCustomer(customer6);
		iWalletService.deposit(customer6, BigDecimal.valueOf(8500.00));
		assertFalse(iWalletService.withDraw(customer6, BigDecimal.valueOf(9000.00)));
	}

}
