package com.cg.PaymentWalletApp.Exception;

@SuppressWarnings("serial")
public class BankException extends Exception {
public BankException(String msg) {
	super(msg);
}
}
